package no.hvl.dat100.prosjekt.kontroll.spill;

public enum HandlingsType {
	TREKK, FORBI, LEGGNED
};
