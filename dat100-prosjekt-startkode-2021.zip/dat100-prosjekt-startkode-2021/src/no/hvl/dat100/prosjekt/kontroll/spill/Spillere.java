package no.hvl.dat100.prosjekt.kontroll.spill;

public enum Spillere {
	
	// INGEN brukes ved oppstart før spiller som starter er valgt
	NORD, SYD, INGEN;
	
}
