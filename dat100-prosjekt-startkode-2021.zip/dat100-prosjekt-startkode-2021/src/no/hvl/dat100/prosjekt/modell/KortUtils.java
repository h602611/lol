package no.hvl.dat100.prosjekt.modell;

import java.util.Random;

import no.hvl.dat100.prosjekt.TODO;

public class KortUtils {

    /**
     * Sorterer en samling. Rekkefølgen er bestemt av compareTo() i Kort-klassen.
     * 
     * @see Kort
     * 
     * @param samling
     *             samling av kort som skal sorteres. 
     */
    
    public static void sorter(KortSamling samling) {
        
        // TODO - START
        int minst;
        Kort Kort1;
        Kort Kort2;
        KortSamling hks;
        hks = new KortSamling();
        Kort[] hjelpekortsamling = samling.getSamling();
        if((!samling.erTom()) && (samling.getAntalKort()>1)) {
            for(int i = 0; i < samling.getAntalKort()-1; i++) {
                minst = i; 
                for(int j = i + 1; j < samling.getAntalKort(); j++) {
                    Kort1 = hjelpekortsamling[j];
                    Kort2 = hjelpekortsamling[minst];
                    if(Kort1.compareTo(Kort2) < 1) {
                        minst = j;
                    }
                }
                if(Kort1 != null) {
                    Kort1 = hjelpekortsamling[i];
                    hjelpekortsamling[i] = hjelpekortsamling[minst];
                    hjelpekortsamling[minst] = Kort1;
                }
                
            }
            for(int i = 0; i < samling.getAntalKort(); i++) {
                if(hjelpekortsamling[i] != null) {
                    hks.leggTil(hjelpekortsamling[i]);
                }
            }
                
            samling = hks;
        }
    }
    
    /**
     * Stokkar en kortsamling. 
     * 
     * @param samling
     *             samling av kort som skal stokkes. 
     */
    public static void stokk(KortSamling samling) {
        int tilfeldig;
        int antall;
        int antallKort;
        int teller = 0;
        KortSamling hks;
        hks = new KortSamling();
        Kort[] hjelpekortsamling = samling.getSamling();
        antallKort = samling.getAntalKort();
        if((!samling.erTom()) && (antallKort > 1)) {
            while(!samling.erTom() && teller <= antallKort) {
                antall = samling.getAntalKort();
                hjelpekortsamling = samling.getSamling();
                teller++;
                tilfeldig = (int) (Math.random() * antall);
            //    if(hjelpekortsamling[tilfeldig] != null) {
                    hks.leggTil(hjelpekortsamling[tilfeldig]);
                    samling.fjern(hjelpekortsamling[tilfeldig]);
                //}
            }
            samling = hks;
        }
    }
}